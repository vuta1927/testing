# SampleASPContainerApp

This is a simple MVC ASP app which is used to demonstrate containers. To see the solution with dockerfile, select the 'completed' branch.
